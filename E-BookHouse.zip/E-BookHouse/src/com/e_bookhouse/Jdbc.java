package com.e_bookhouse;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Jdbc{
	
	
	public void insert(String username, String password){
		String sql = "INSERT INTO user(username, password)"
				+ "VALUES('" + username + "','" + password + "')";
		String urlString = "jdbc:mysql://localhost:3306/e_bookhouse";
		String usernameString = "root";
		String passwordString = "ls8180807";
		Connection connection = null;
		Statement statement = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(urlString, usernameString, passwordString);
			statement = connection.createStatement();
			statement.executeUpdate(sql);
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*public void delete(){
		String sql = "DELETE FROM tbl_user WHERE name='xiaohei'";
		String urlString = "jdbc:mysql://localhost:3306/e_bookhouse";
		String usernameString = "root";
		String passwordString = "ls8180807";
		Connection connection = null;
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.executeUpdate(sql);
			connection.close();
		} catch (Exception e) {
			
		}
	}
	
	public void update(){
		String sql = "UPDATE tbl_user SET password='456132' WHERE email='xiaohei@163.com'";
		Connection connection = null;
		Statement statement = null;
		int count = 0;
		try {
			connection = getConnection();
			statement = connection.createStatement();
			count = statement.executeUpdate(sql);
			System.out.println("在数据库中更新了" + count + "条数据");
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}*/
	
	public static void select(){
		String sqlString = "SELECT * FROM user";
		String urlString = "jdbc:mysql://localhost:3306/e_bookhouse";
		String usernameString = "root";
		String passwordString = "ls8180807";
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DriverManager.getConnection(urlString, usernameString, passwordString);
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlString);
			while(resultSet.next()){
				
				System.out.print(resultSet.getString("username") + " ");
				System.out.print(resultSet.getString("password") + " ");
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				resultSet.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			try {
				statement.close();
			} catch (Exception e3) {
				e3.printStackTrace();
			}
			try {
				connection.close();
			} catch (Exception e4) {
				e4.printStackTrace();
			}
		}
	}
	public static void main(String[] args){
		select();
	}
}